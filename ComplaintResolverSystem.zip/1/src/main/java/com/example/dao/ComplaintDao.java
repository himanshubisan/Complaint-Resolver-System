package com.example.dao;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.model.Complaint;


@Transactional
@Component
public class ComplaintDao {

			@Autowired
			  public SessionFactory _sessionFactory;
			  
			  public Session getSession() {
				  System.out.println("session==>"+_sessionFactory.getCurrentSession());
			    return _sessionFactory.getCurrentSession();
			  }
	  

	public void insertComplaint(Complaint complaint) {
		// TODO Auto-generated method stub
	
		getSession().save(complaint);
	}

}
