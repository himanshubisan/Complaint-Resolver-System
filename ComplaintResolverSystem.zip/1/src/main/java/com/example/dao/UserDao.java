package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.model.User;




@Transactional
@Component
public class UserDao {
	
	@Autowired
	  public SessionFactory _sessionFactory;
	  
	  public Session getSession() {
		  System.out.println("session==>"+_sessionFactory.getCurrentSession());
	    return _sessionFactory.getCurrentSession();
	  }

	  public void insertUser(User user) {
		  
	        

	       getSession().save(user);
	        
	  }
	  
	  
	  public User retrieve(User user) {
		  System.out.println("In retriev");
		  User user1=null;
		  String name=user.getUser_FullName();
		  String pass=user.getUser_Password();
		  System.out.println(name+" "+pass);
		  String hql = "FROM User E WHERE E.User_FullName = '" + name + "' and E.User_Password = '" + pass + "'";
		  Query query = (Query) getSession().createQuery(hql);
		  List results = query.list();
		  if(results==null)
		  {
			  return null;
		  }
		  else
		  {
			  for (int i = 0; i < results.size(); i++) {
				   user1 = (User) results.get(i);
				   System.out.println(user1.getUser_Password());
				  }
			  return user1;
		  }

		 }
	  
	

}
