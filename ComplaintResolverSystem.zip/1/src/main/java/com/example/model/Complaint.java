package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Complaint {
@Id
@GeneratedValue
private int complaintId;
private String complaintType;
private String complaintDesc;

public int getComplaintId() {
	return complaintId;
}
public void setComplaintId(int complaintId) {
	this.complaintId = complaintId;
}
public String getComplaintType() {
	return complaintType;
}
public void setComplaintType(String complaintType) {
	this.complaintType = complaintType;
}
public String getComplaintDesc() {
	return complaintDesc;
}
public void setComplaintDesc(String complaintDesc) {
	this.complaintDesc = complaintDesc;
}

public Complaint() {
	super();
}
public Complaint(int complaintId, String complaintType, String complaintDesc, int complaintPriority) {
	super();
	this.complaintId = complaintId;
	this.complaintType = complaintType;
	this.complaintDesc = complaintDesc;

}
@Override
public String toString() {
	return "Complaint [complaintId=" + complaintId + ", complaintType=" + complaintType + ", complaintDesc="
			+ complaintDesc + "]";
}


}
