package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.model.Complaint;
import com.example.model.User;




@Transactional
@Component
public class UserDao {
	
	@Autowired
	  public SessionFactory _sessionFactory;
	  
	  public Session getSession() {
		  System.out.println("session==>"+_sessionFactory.getCurrentSession());
	    return _sessionFactory.getCurrentSession();
	  }

	  public void insertUser(User user) {
		  
	        

	       getSession().save(user);
	        
	  }
	  
	  
	  public User retrieve(User user) {
		  System.out.println("In retriev");
		  User user1=null;
		  String name=user.getUserName();
		  String pass=user.getUserPassword();
		  System.out.println(name+" "+pass);
		  String hql = "FROM User E WHERE E.userName = '" + name + "' and E.userPassword = '" + pass + "'";
		  Query query = (Query) getSession().createQuery(hql);
		  List results = query.list();
		  if(results==null)
		  {
			  return null;
		  }
		  else
		  {
			  for (int i = 0; i < results.size(); i++) {
				   user1 = (User) results.get(i);
				   System.out.println(user1.getUserPassword());
				  }
			  return user1;
		  }

		 }
	  
	  @SuppressWarnings("unchecked")
		public List<User> getAllUsers() {
			Session session =this._sessionFactory.getCurrentSession();
			List<User> userList = session.createQuery("from User").list();
			for(User u :userList) {
				System.out.println(u);
			}
			return userList;
		}

	
	

}
