package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
public class User {

	
	@Id  
    @GeneratedValue 
    private int User_id;
	private String User_FullName;
	private String User_Password;
	private long  User_MobileNumber;
	private String User_Address;
	private String User_Email;
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUser_id() {
		return User_id;
	}
	public void setUser_id(int user_id) {
		this.User_id = user_id;
	}
	public String getUser_FullName() {
		return User_FullName;
	}
	public void setUser_FullName(String user_FullName) {
		this.User_FullName = user_FullName;
	}
	public String getUser_Password() {
		return User_Password;
	}
	public void setUser_Password(String user_Password) {
		this.User_Password = user_Password;
	}
	public long getUser_MobileNumber() {
		return User_MobileNumber;
	}
	public void setUser_MobileNumber(long user_MobileNumber) {
		this.User_MobileNumber = user_MobileNumber;
	}
	public String getUser_Address() {
		return User_Address;
	}
	public void setUser_Address(String user_Address) {
		this.User_Address = user_Address;
	}
	public String getUser_Email() {
		return User_Email;
	}
	public void setUser_Email(String user_Email) {
		this.User_Email = user_Email;
	}

	public User(int user_id, String user_FullName, String user_Password, long user_MobileNumber, String user_Address,
			String user_Email) {
		super();
		this.User_id = user_id;
		this.User_FullName = user_FullName;
		this.User_Password = user_Password;
		this.User_MobileNumber = user_MobileNumber;
		this.User_Address = user_Address;
		this.User_Email = user_Email;
	}
	
	
	
	
}
