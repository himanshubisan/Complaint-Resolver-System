package com.example.demo;



import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.model.Complaint;
import com.example.model.User;
import com.example.dao.ComplaintDao;
import com.example.dao.UserDao;

@Controller
public class Home {
	
	@Autowired
	public UserDao userDao;
	@Autowired
	public ComplaintDao complaintDao;
	public User loginUser=null;
	@Autowired
	private HttpServletRequest httpServletReq;
	
	@RequestMapping({"/","/home"})
	public String Hello(User user,Model model)
	{
		 model.addAttribute("user", user);
		 
		return "index";
		
	}
	
//	@RequestMapping("/login")
//	public String login() 
//	{
//			return "login";
//		}
	
	
	@RequestMapping("/register")
	public String registration() 
	{
		return "registration";
	}

	@RequestMapping("/admin")
	public String admin() {
		return "AdminLogin";
	}
    
//    @GetMapping("/form")
//    public String formGet() {
//        return "registration";
//    }
    
    @PostMapping("/form")
    public String formPost(User user, Model model) {
        model.addAttribute("user", user);
        System.out.println("controller===>"+user.getUserName());
       userDao.insertUser(user);
        return "index";
    }
    
    @RequestMapping(value="/valid",method=RequestMethod.POST)
    public String login(User user, Model model) {
       
//		  String name=user.getUser_FullName();
//		  String pass=user.getUser_Password();
//		  System.out.println(name+" "+pass);
        loginUser=userDao.retrieve(user);
        System.out.println("from user"+loginUser);
        if(loginUser!=null)
        {
        	
        	 model.addAttribute("user", loginUser);
        	return "complaint";
        }
        return "Invalid";
    }
    
    @RequestMapping(value="/ComplaintWater",method=RequestMethod.GET)
	public String water(Model model,User user) 
	{
        //System.out.println("from complaintWater"+loginUser);

    	
    	model.addAttribute("user", loginUser);
    	 /*model.addAttribute("user",httpServletReq.getAttribute("user"));
    	 System.out.println("DB==>"+httpServletReq.getAttribute("user"));*/
			return "water";
		}
    @RequestMapping(value="/ComplaintElectricity",method=RequestMethod.GET)
 	public String electricity(Model model,User user) 
 	{
    	model.addAttribute("user", loginUser);

 			return "electricity";
 		}
    @RequestMapping(value="/ComplaintPollution",method=RequestMethod.GET)
 	public String pollution(Model model,User user) 
 	{
    	model.addAttribute("user", loginUser);

 			return "pollution";
 		}
    @RequestMapping(value="/ComplaintDrainage",method=RequestMethod.GET)
 	public String drainage(Model model,User user) 
 	{
    	model.addAttribute("user", loginUser);

 			return "drain";
 		}
    @RequestMapping(value="/ComplaintTransport",method=RequestMethod.GET)
 	public String transport(Model model,User user) 
 	{
    	model.addAttribute("user", loginUser);

 			return "transport";
 		}
    @RequestMapping(value="/ComplaintRoad",method=RequestMethod.GET)
 	public String road(Model model,User user) 
 	{
    	model.addAttribute("user", loginUser);

 			return "road";
 		}
	@PostMapping("/complaints")
   // @RequestMapping(value="/complaints",method=RequestMethod.POST)
	  public String addComplaint(Complaint complaint,User user, Model model) {
        model.addAttribute("complaint", complaint);
        //model.addAttribute("user", user);
        //System.out.println("controller===>"+user.getUser_FullName());
        System.out.println("User Id:"+user.getUserId());
        System.out.println("from controller"+complaint.getUser());
        System.out.println("in complaints");
       complaintDao.insertComplaint(complaint,user);

        return "complaint_success";
    }
	
	@RequestMapping(value="/listUser",method=RequestMethod.GET)
	public String listUsers(Model model) {
		//model.addAttribute("user",new User());
		//model.addAttribute("listUsers", this.userDao.getAllUsers());

		model.addAttribute("complaint",new Complaint());
		model.addAttribute("listUser", this.complaintDao.getAllComplaints());

		return "listComplaints";
		
	}
//	@RequestMapping(value="/listUsers",method=RequestMethod.GET)
//	 public String listComplaints(Model model) {
//		
//		model.addAttribute("complaint",new Complaint());
//		model.addAttribute("listComplaints", this.complaintDao.getAllComplaints());
//		return "listComplaints";
//		
//	}
	@RequestMapping(value="/test",method=RequestMethod.GET)
	public @ResponseBody String test(Model model) {
		
		complaintDao.test();
		return "succes";
	}
	
	
}
