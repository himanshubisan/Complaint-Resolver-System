package com.example.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Complaint {
@Id
@GeneratedValue
private int complaintId;
private String complaintType;
private String complaintDesc;
private String priority;


@ManyToOne
@JoinColumn(name = "userId")
private User user;

public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}

public String getPriority() {
	return priority;
}
public void setPriority(String priority) {
	this.priority = priority;
}
public int getComplaintId() {
	return complaintId;
}
public void setComplaintId(int complaintId) {
	this.complaintId = complaintId;
}
public String getComplaintType() {
	return complaintType;
}
public void setComplaintType(String complaintType) {
	this.complaintType = complaintType;
}
public String getComplaintDesc() {
	return complaintDesc;
}
public void setComplaintDesc(String complaintDesc) {
	this.complaintDesc = complaintDesc;
}

public Complaint() {
	super();
}


public Complaint(int complaintId, String complaintType, String complaintDesc, String priority, User user) {
	super();
	this.complaintId = complaintId;
	this.complaintType = complaintType;
	this.complaintDesc = complaintDesc;
	this.priority = priority;
	this.user = user;
}
@Override
public String toString() {
	return "Complaint [complaintId=" + complaintId + ", complaintType=" + complaintType + ", complaintDesc="
			+ complaintDesc + ", priority=" + priority + ", user=" + user + "]";
}

}
